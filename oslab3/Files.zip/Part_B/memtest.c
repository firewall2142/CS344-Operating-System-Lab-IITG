#include "types.h"
#include "user.h"
#include "stat.h"

int
func_mem(int* page)
{
	int* pt1 = page, *pt2 = page + 1;
	*page = 1;
	*(page + 1) = 1;
	for(int itp = 2; itp < 1024; itp++) {
		*(page + itp) = ((*pt1) + (*pt2)) % 10000;
		pt1++;
		pt2++;
	}
	
	int a = 1, b = 1;
	if (*page != a)
		return 0;
		
	for(int itp = 1; itp < 1024; itp++) {
		if (*(page + itp) != b) {
			return 0;
		}
		b = a+b;
		a = b-a;
		b %= 10000;
	}

	return 1;
}

int
main(int argc, char *argv[])
{
	int numforks = 20;
	int par = 0;
	int* flag = malloc(4);
	*flag = 1;
	
	if(argc >= 2)
		numforks = atoi(argv[1]);  
	
	int id = 0;

	for(int childitr = 1; childitr <= numforks; childitr++){
		if (!(*flag))
			break;

		id = fork();

		if(id == 0) {
			par += childitr;
		
			for(int itr = 0; itr < 10; itr++) {
				
				void* new_mem;
				new_mem = malloc(4096);
				if(new_mem == 0) {
					printf(1, "memtest failed\n");
					*flag = 0;
					break;
				}
				else if(!func_mem((int*)new_mem)) {
					printf(1, "memtest failed\n");
					*flag = 0;
					break;
				}
			}
			if(*flag)
					printf(1, "memtest OK\n");
			break;
		}
	}
  // wait for the children to finish
	while(wait() != -1);
	if(par == 0)
		printf(1, "memtest Done\n");
	exit();
}
