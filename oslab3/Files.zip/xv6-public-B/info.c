#include "types.h"
#include "stat.h"
#include "user.h"

int main(void){
  printf(1, "Num Processes  = %d\n", getNumProc());
  printf(1, "Max Process id = %d\n", getMaxPid());
  exit();
}
